package com.cs360.dylannguweighttracker.model;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.ForeignKey;
import androidx.room.PrimaryKey;

import static androidx.room.ForeignKey.CASCADE;

// This class is used to model a daily weight that the user logs
// The attributes are used to populate a SQLite table inside the weight.db database
@Entity(foreignKeys = @ForeignKey(entity = User.class, parentColumns = "username",
        childColumns = "user", onDelete = CASCADE))
public class DailyWeight {

    @PrimaryKey(autoGenerate = true)
    @ColumnInfo(name = "id")
    private Long mId;
    @ColumnInfo(name = "daily_weight")
    private Float mDailyWeight;
    @ColumnInfo(name = "date")
    private String mDate;
    @ColumnInfo(name = "user")
    private String mUser;

    public DailyWeight(@NonNull Float dailyWeight) {
        mDailyWeight = dailyWeight;

        LocalDateTime today = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        mDate = today.format(formatter);
    }

    public Long getId() {
        return mId;
    }

    public void setId(Long Id) {
        this.mId = Id;
    }

    public Float getDailyWeight() {
        return mDailyWeight;
    }

    public void setDailyWeight(Float dailyWeight) {
        this.mDailyWeight = dailyWeight;
    }

    public String getUser() {
        return mUser;
    }

    public void setUser(String username) {
        this.mUser = username;
    }

    public String getDate() {
        return mDate;
    }

    public void setDate(String date) {
        this.mDate = date;
    }

}
