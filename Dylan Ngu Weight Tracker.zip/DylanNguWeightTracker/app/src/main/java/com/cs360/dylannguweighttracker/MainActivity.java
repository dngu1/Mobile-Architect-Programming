package com.cs360.dylannguweighttracker;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;

import com.cs360.dylannguweighttracker.dialog.WarningDialogFragment;
import com.cs360.dylannguweighttracker.model.User;
import com.cs360.dylannguweighttracker.viewmodel.UserViewModel;

public class MainActivity extends AppCompatActivity {

    private User mUser;
    private UserViewModel mUserViewModel;
    private EditText mUsername;
    private EditText mPassword;
    private TextView mGoalWeightLabel;
    private EditText mGoalWeight;

    private Button mLoginButton;
    private Button mCreateAccountButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mUserViewModel = new UserViewModel(getApplication());

        mUsername = findViewById(R.id.username);
        mPassword = findViewById(R.id.password);

        mGoalWeightLabel = findViewById(R.id.goalWeightLabel);
        mGoalWeight = findViewById(R.id.goalWeight);

        mLoginButton = findViewById(R.id.loginButton);
        mCreateAccountButton = findViewById(R.id.createAccountButton);

        RadioGroup mRadioGroup = findViewById(R.id.loginRadioGroup);

        // Change main activity screen depending on radio button selection
        mRadioGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(RadioGroup group, int checkedId) {
                if (checkedId == R.id.radioCreate) {
                    // expose goal weight views and create account button
                    mGoalWeightLabel.setVisibility(View.VISIBLE);
                    mGoalWeight.setVisibility(View.VISIBLE);
                    mCreateAccountButton.setVisibility(View.VISIBLE);
                    //disable login button
                    mLoginButton.setVisibility(View.GONE);
                }
                else if (checkedId == R.id.radioLogin) {
                    // disable goal weights and create account button
                    mGoalWeightLabel.setVisibility(View.GONE);
                    mGoalWeight.setVisibility(View.GONE);
                    mCreateAccountButton.setVisibility(View.GONE);
                    //enable login button
                    mLoginButton.setVisibility(View.VISIBLE);
                }
            }
        });
    }

    public void onLoginClick(View view) {
        String username = mUsername.getText().toString();
        String password = mPassword.getText().toString();

        if (mUserViewModel.getUser(username) != null) {
            mUser = mUserViewModel.getUser(username);

            if (mUser.getPassword().equals(password)) {
                Intent intent = new Intent(this, DailyWeightActivity.class);
                intent.putExtra(DailyWeightActivity.EXTRA_USERNAME, username);
                intent.putExtra(DailyWeightActivity.EXTRA_GOAL_WEIGHT, mUser.getGoalWeight());
                startActivity(intent);
            }
        }
        else {
            // FragmentManager is used to interact with alert dialogs
            FragmentManager fragmentManager = getSupportFragmentManager();
            // instantiate warning dialog
            WarningDialogFragment dialog = new WarningDialogFragment("ERROR", "Username or Password incorrect. Try again or create new account.");
            dialog.show(fragmentManager, "warningDialog");
        }
    }

    public void onCreateClick(View view) {
        FragmentManager fragmentManager = getSupportFragmentManager();

        String username = mUsername.getText().toString();
        String password = mPassword.getText().toString();
        String goalWeightString = mGoalWeight.getText().toString();

        // check to see if all fields are filled out
        if (!username.isEmpty() || !password.isEmpty() || !goalWeightString.isEmpty()) {
            Float goalWeight = Float.parseFloat(goalWeightString);

            // check to see if username exists
            if (mUserViewModel.getUser(username) != null) {
                WarningDialogFragment dialog = new WarningDialogFragment("ERROR", "Username unavailable, enter new username.");
                dialog.show(fragmentManager, "warningDialog");
            }
            else {
                mUser = new User(username, password, goalWeight);
                mUserViewModel.addUser(mUser);

                Intent intent = new Intent(this, DailyWeightActivity.class);
                intent.putExtra(DailyWeightActivity.EXTRA_USERNAME, mUser.getUsername());
                intent.putExtra(DailyWeightActivity.EXTRA_GOAL_WEIGHT, mUser.getGoalWeight());
                startActivity(intent);
            }
        }
        else {
            WarningDialogFragment dialog = new WarningDialogFragment("ERROR", "All fields must be filled out.");
            dialog.show(fragmentManager, "warningDialog");
        }
    }
}