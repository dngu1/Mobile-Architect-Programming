package com.cs360.dylannguweighttracker.repo;

import androidx.room.Database;
import androidx.room.RoomDatabase;
import com.cs360.dylannguweighttracker.model.User;
import com.cs360.dylannguweighttracker.model.DailyWeight;

// This class creates a Room database
@Database(entities = {User.class, DailyWeight.class}, version = 1)
public abstract class WeightTrackerDatabase extends RoomDatabase {
    public abstract UserDao userDao();
    public abstract DailyWeightDao dailyWeightDao();
}
