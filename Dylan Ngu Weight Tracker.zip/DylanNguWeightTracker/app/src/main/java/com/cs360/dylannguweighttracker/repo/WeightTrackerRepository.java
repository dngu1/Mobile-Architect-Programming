package com.cs360.dylannguweighttracker.repo;

import android.content.Context;

import androidx.lifecycle.LiveData;
import androidx.room.Room;
import com.cs360.dylannguweighttracker.model.User;
import com.cs360.dylannguweighttracker.model.DailyWeight;
import java.util.List;

// This class calls methods from our DAO classes in order to interact with the Room Database
public class WeightTrackerRepository {
    private static WeightTrackerRepository mWeightTrackerRepo;
    private final UserDao mUserDao;
    private final DailyWeightDao mDailyWeightDao;

    public static WeightTrackerRepository getInstance(Context context) {
        if (mWeightTrackerRepo == null) {
            mWeightTrackerRepo = new WeightTrackerRepository(context);
        }
        return mWeightTrackerRepo;
    }

    private WeightTrackerRepository(Context context) {
        WeightTrackerDatabase database = Room.databaseBuilder(context, WeightTrackerDatabase.class, "weight.db")
                .allowMainThreadQueries()
                .build();

        mUserDao = database.userDao();
        mDailyWeightDao = database.dailyWeightDao();
    }

    public void addUser(User user) {
        mUserDao.addUser(user);
    }

    public User getUser(String username) {
        return mUserDao.getUser(username);
    }

    public void deleteUser(User user) {
        mUserDao.deleteUser(user);
    }

    public void updateUser(User user) {
        mUserDao.updateUser(user);
    }

    public void addDailyWeight(DailyWeight dailyWeight) {
        long id = mDailyWeightDao.addDailyWeight(dailyWeight);
        dailyWeight.setId(id);
    }

    public LiveData<DailyWeight> getDailyWeight(long dailyWeightId) {
        return mDailyWeightDao.getDailyWeight(dailyWeightId);
    }

    public LiveData<List<DailyWeight>> getDailyWeights(String username) {
        return mDailyWeightDao.getDailyWeights(username);
    }

    public void updateDailyWeight(DailyWeight dailyWeight) {
        mDailyWeightDao.updateDailyWeight(dailyWeight);
    }

    public void deleteDailyWeight(DailyWeight dailyWeight) {
        mDailyWeightDao.deleteDailyWeight(dailyWeight);
    }

}
