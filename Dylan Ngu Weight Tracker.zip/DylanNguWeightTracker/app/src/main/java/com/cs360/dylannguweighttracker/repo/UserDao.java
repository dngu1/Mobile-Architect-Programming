package com.cs360.dylannguweighttracker.repo;

import androidx.lifecycle.LiveData;
import androidx.room.*;
import com.cs360.dylannguweighttracker.model.User;

// This is data access class that defines CRUD methods for our User table
@Dao
public interface UserDao {
    @Query("SELECT * FROM User WHERE username = :username")
    User getUser(String username);

    @Insert
    void addUser(User user);

    @Update
    void updateUser(User user);

    @Delete
    void deleteUser(User user);
}
