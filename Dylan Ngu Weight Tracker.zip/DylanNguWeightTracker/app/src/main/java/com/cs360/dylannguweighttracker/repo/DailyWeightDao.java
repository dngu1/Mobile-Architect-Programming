package com.cs360.dylannguweighttracker.repo;

import androidx.lifecycle.LiveData;
import androidx.room.*;
import com.cs360.dylannguweighttracker.model.DailyWeight;
import java.util.List;

// This class is defines CRUD methods for our DailyWeight Table
@Dao
public interface DailyWeightDao {
    @Query("SELECT * FROM DailyWeight WHERE id = :id")
    LiveData<DailyWeight> getDailyWeight(long id);

    @Query("SELECT * FROM DailyWeight WHERE user = :user ORDER BY date")
    LiveData<List<DailyWeight>> getDailyWeights(String user);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    long addDailyWeight(DailyWeight dailyWeight);

    @Update
    void updateDailyWeight(DailyWeight dailyWeight);

    @Delete
    void deleteDailyWeight(DailyWeight dailyWeight);
}
