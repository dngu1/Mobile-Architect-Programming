package com.cs360.dylannguweighttracker;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelStore;
import androidx.lifecycle.ViewModelStoreOwner;

import com.cs360.dylannguweighttracker.model.DailyWeight;
import com.cs360.dylannguweighttracker.viewmodel.DailyWeightListViewModel;

import java.util.ArrayList;
import java.util.List;

// This class contains methods used to populate the daily weight table for the DailyWeightActivity
public class WeightTableAdapter extends BaseAdapter{

    private final Context mWeightTableContext;
    private final List<DailyWeight> mDailyWeightList;
    private final DailyWeightListViewModel mDailyWeightListViewModel;

    public WeightTableAdapter(Context context, List<DailyWeight> dailyWeights, DailyWeightListViewModel dailyWeightListViewModel) {
        mDailyWeightList = dailyWeights;
        mWeightTableContext = context;
        mDailyWeightListViewModel = dailyWeightListViewModel;
    }

    @Override
    public int getCount() {
        return mDailyWeightList.size();
    }

    @Override
    public Object getItem(int i) {
        return mDailyWeightList.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @SuppressLint("SetTextI18n")
    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        WeightTableViewHolder holder;

        if (view ==null){
            LayoutInflater weightTableInflater = (LayoutInflater) mWeightTableContext.getSystemService(Activity.LAYOUT_INFLATER_SERVICE);
            view = weightTableInflater.inflate(R.layout.daily_weight, null);

            holder = new WeightTableViewHolder();
            holder.dateView = view.findViewById(R.id.dailyWeightDate);
            holder.weightView = view.findViewById(R.id.dailyWeightWeight);
            holder.deleteButton = view.findViewById(R.id.deleteWeightButton);

            view.setTag(holder);
        }
        else {
            holder = (WeightTableViewHolder) view.getTag();
        }

        DailyWeight dailyWeight = (DailyWeight) getItem(i);
        holder.dateView.setText(dailyWeight.getDate());
        holder.weightView.setText(dailyWeight.getDailyWeight().toString() + " lbs");
        //holder.deleteButton.

        holder.deleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                mDailyWeightListViewModel.deleteDailyWeight(dailyWeight);
            }
        });

        return view;

    }

}
