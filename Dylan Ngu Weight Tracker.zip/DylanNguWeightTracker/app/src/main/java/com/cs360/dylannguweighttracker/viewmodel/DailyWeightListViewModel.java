package com.cs360.dylannguweighttracker.viewmodel;

import android.app.Application;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import com.cs360.dylannguweighttracker.model.DailyWeight;
import com.cs360.dylannguweighttracker.repo.WeightTrackerRepository;
import java.util.List;
public class DailyWeightListViewModel extends AndroidViewModel {
    private final WeightTrackerRepository mWeightTrackerRepo;

    public DailyWeightListViewModel(Application application) {
        super(application);
        mWeightTrackerRepo = WeightTrackerRepository.getInstance(application.getApplicationContext());
    }

    public LiveData<List<DailyWeight>> getDailyWeights(String username) {
        return mWeightTrackerRepo.getDailyWeights(username);
    }

    public LiveData<DailyWeight> getDailyWeight(long id) {
        return mWeightTrackerRepo.getDailyWeight(id);
    }

    public void addDailyWeight(DailyWeight dailyWeight) {
        mWeightTrackerRepo.addDailyWeight(dailyWeight);
    }

    public void deleteDailyWeight(DailyWeight dailyWeight) {
        mWeightTrackerRepo.deleteDailyWeight(dailyWeight);
    }

}
