package com.cs360.dylannguweighttracker;

import android.content.Intent;
import android.os.Bundle;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;
import androidx.lifecycle.ViewModelProvider;

import com.cs360.dylannguweighttracker.dialog.WarningDialogFragment;
import com.cs360.dylannguweighttracker.model.DailyWeight;
import com.cs360.dylannguweighttracker.viewmodel.DailyWeightListViewModel;

public class AddWeightActivity extends AppCompatActivity {

    public static final String EXTRA_USERNAME = "com.cs360.dylannguweighttracker.username";
    public static final String EXTRA_GOAL_WEIGHT = "com.cs360.dylannguweighttracker.goal_weight";

    private DailyWeightListViewModel mDailyWeightListViewModel;
    private String mUsername;
    private Float mGoalWeight;
    private EditText mDailyWeightText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_weight);

        mDailyWeightText = findViewById(R.id.weight_edit_text);

        findViewById(R.id.saveButton).setOnClickListener(view -> saveButtonClick());

        // get username and goal weight from Daily Weight Activity
        Intent intent = getIntent();
        mUsername = intent.getStringExtra(EXTRA_USERNAME);
        mGoalWeight = intent.getFloatExtra(EXTRA_GOAL_WEIGHT,0);

        mDailyWeightListViewModel = new ViewModelProvider(this).get(DailyWeightListViewModel.class);
    }

    public void saveButtonClick() {
        // todo: implement code
        String dailyWeightString = mDailyWeightText.getText().toString();

        // check to see if weight is entered
        if (!dailyWeightString.isEmpty()) {
            Float weight = Float.parseFloat(dailyWeightString);

            DailyWeight dailyWeight = new DailyWeight(weight);
            dailyWeight.setUser(mUsername);

            mDailyWeightListViewModel.addDailyWeight(dailyWeight);

            if (weight.equals(mGoalWeight)) {
                setResult(RESULT_FIRST_USER);
            }
            else {
                setResult(RESULT_OK);
            }
            finish();
        }
        else {
            FragmentManager fragmentManager = getSupportFragmentManager();
            // instantiate warning dialog
            WarningDialogFragment dialog = new WarningDialogFragment("ERROR", "Must enter valid body weight");
            dialog.show(fragmentManager, "warningDialog");
        }
    }

}