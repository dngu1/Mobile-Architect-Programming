package com.cs360.dylannguweighttracker.viewmodel;

import android.app.Application;

import androidx.lifecycle.AndroidViewModel;

import com.cs360.dylannguweighttracker.model.User;
import com.cs360.dylannguweighttracker.repo.WeightTrackerRepository;


public class UserViewModel extends AndroidViewModel {
    private final WeightTrackerRepository mWeightTrackerRepo;

    public UserViewModel(Application application) {
        super(application);
        mWeightTrackerRepo = WeightTrackerRepository.getInstance(application.getApplicationContext());
    }

    public User getUser(String username) {
        return mWeightTrackerRepo.getUser(username);
    }

    public void addUser(User user) {
        mWeightTrackerRepo.addUser(user);
    }

}
