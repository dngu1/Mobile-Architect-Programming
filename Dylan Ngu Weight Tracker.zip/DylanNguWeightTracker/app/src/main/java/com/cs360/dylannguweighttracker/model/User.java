package com.cs360.dylannguweighttracker.model;

import androidx.annotation.NonNull;
import androidx.room.ColumnInfo;
import androidx.room.Entity;
import androidx.room.Ignore;
import androidx.room.PrimaryKey;

// This class is used to model a User
// The attributes are used to populate a SQLite table inside the weight.db database
@Entity
public class User {
    @NonNull
    @PrimaryKey
    @ColumnInfo(name = "username")
    private String mUsername;

    @ColumnInfo(name = "password")
    private String mPassword;

    @ColumnInfo(name = "goal_weight")
    private Float mGoalWeight;

    public User(@NonNull String username, String password, Float goalWeight) {
        mUsername = username;
        mPassword = password;
        mGoalWeight = goalWeight;
    }

    @Ignore
    public User(@NonNull String username) {
        mUsername = username;
    }

    public String getUsername() {
        return mUsername;
    }

    public void setUsername(String username) {
        this.mUsername = username;
    }

    public String getPassword() {
        return mPassword;
    }

    public void setPassword(String password) {
        this.mPassword = password;
    }

    public Float getGoalWeight() {
        return mGoalWeight;
    }

    public void setGoalWeight(Float goalWeight) {
        this.mGoalWeight = goalWeight;
    }
}
