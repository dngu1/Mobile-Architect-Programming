package com.cs360.dylannguweighttracker;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentManager;
import androidx.lifecycle.ViewModelProvider;

import com.cs360.dylannguweighttracker.dialog.WarningDialogFragment;
import com.cs360.dylannguweighttracker.model.DailyWeight;
import com.cs360.dylannguweighttracker.model.User;
import com.cs360.dylannguweighttracker.viewmodel.DailyWeightListViewModel;

import java.util.List;

public class DailyWeightActivity extends AppCompatActivity {

    public static final String EXTRA_USERNAME = "com.cs360.dylannguweighttracker.username";
    public static final String EXTRA_GOAL_WEIGHT = "com.cs360.dylannguweighttracker.goal_weight";

    private DailyWeightListViewModel mDailyWeightListViewModel;
    private User mUser;

    private WeightTableAdapter mWeightTableAdapter;
    private TextView mGoalWeightView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_daily_weights);

        // get username and goal weight from main activity
        Intent intent = getIntent();
        String username = intent.getStringExtra(EXTRA_USERNAME);
        Float goalWeight = intent.getFloatExtra(EXTRA_GOAL_WEIGHT,0);
        if (username != null) {
            mUser = new User(username);
            mUser.setGoalWeight(goalWeight);
        }
        mGoalWeightView = findViewById(R.id.goalWeightView);
        mGoalWeightView.setText(String.format("Goal Weight: %s", goalWeight));
        // get daily weights for user
        mDailyWeightListViewModel = new ViewModelProvider(this).get(DailyWeightListViewModel.class);
        // Calls updateUI whenever live data changes
        mDailyWeightListViewModel.getDailyWeights(username).observe(this, this::updateUI);

        // checks for sms send permission
        boolean smsPermission = hasSmsPermission();

    }

    // Displays daily weights on table
    private void updateUI(List<DailyWeight> dailyWeightList) {
        mWeightTableAdapter = new WeightTableAdapter(this, dailyWeightList, mDailyWeightListViewModel);
        final ListView weightTableView = findViewById(R.id.weightTableView);
        weightTableView.setAdapter(mWeightTableAdapter);
    }

    public void onAddWeightClick(View view){
        // method launches addWeightActivity and provides username and goal weight
        Intent intent = new Intent(this, AddWeightActivity.class);
        intent.putExtra(AddWeightActivity.EXTRA_USERNAME, mUser.getUsername());
        intent.putExtra(AddWeightActivity.EXTRA_GOAL_WEIGHT, mUser.getGoalWeight());
        mAddWeightResultLauncher.launch(intent);
    }

    private final ActivityResultLauncher<Intent> mAddWeightResultLauncher = registerForActivityResult(
            new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if (result.getResultCode() == Activity.RESULT_OK) {
                    Toast.makeText(DailyWeightActivity.this, "Weight Added", Toast.LENGTH_SHORT).show();
                }
                if (result.getResultCode() == Activity.RESULT_FIRST_USER) {
                    FragmentManager fragmentManager = getSupportFragmentManager();
                    WarningDialogFragment dialog = new WarningDialogFragment(
                            "CONGRATULATIONS", "You have reached your goal weight.");
                    dialog.show(fragmentManager, "warningDialog");

                    if (hasSmsPermission()) {
                        String samplePhoneNumber = "";
                        //SmsManager smsManager = this.getSystemService(SmsManager.class);
                        //smsManager.sendTextMessage(samplePhoneNumber, null, "Reached goal weight", null, null);
                    }
                }
            });

    private final int REQUEST_SEND_SMS = 0;
    private boolean hasSmsPermission() {
        String smsPermission = Manifest.permission.SEND_SMS;
        if (ContextCompat.checkSelfPermission(this, smsPermission) != PackageManager.PERMISSION_GRANTED) {
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, smsPermission )) {
                Toast.makeText(this, "SMS send permission needed", Toast.LENGTH_LONG).show();
            }
            else {
                ActivityCompat.requestPermissions(this, new String[] { Manifest.permission.SEND_SMS }, REQUEST_SEND_SMS);
            }
            return false;
        }
        return true;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == REQUEST_SEND_SMS) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                // Permission granted
                Toast.makeText(getApplicationContext(), "SMS send permission granted.", Toast.LENGTH_LONG).show();
            }
            else {
                // Permission denied
                Toast.makeText(this, "SMS send permission denied.", Toast.LENGTH_LONG).show();
            }

        }
    }

}