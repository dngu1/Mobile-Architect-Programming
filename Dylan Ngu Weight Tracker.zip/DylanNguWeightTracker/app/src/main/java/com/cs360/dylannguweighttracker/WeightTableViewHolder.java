package com.cs360.dylannguweighttracker;

import android.widget.Button;
import android.widget.TextView;

public class WeightTableViewHolder {
    public TextView dateView;
    public TextView weightView;
    public Button deleteButton;
}
