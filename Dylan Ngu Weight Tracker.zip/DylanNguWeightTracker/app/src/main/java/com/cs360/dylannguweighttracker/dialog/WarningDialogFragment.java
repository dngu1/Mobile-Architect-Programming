package com.cs360.dylannguweighttracker.dialog;

import android.app.AlertDialog;
import android.app.Dialog;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

public class WarningDialogFragment extends DialogFragment {
    private String mTitle;
    private String mMessage;

    public WarningDialogFragment(String title, String message) {
        mTitle = title;
        mMessage = message;
    }
    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstance) {
        AlertDialog.Builder builder = new AlertDialog.Builder(requireActivity());
        builder.setTitle(mTitle);
        builder.setMessage(mMessage);
        builder.setPositiveButton("OK", null);
        return builder.create();
    }
}
